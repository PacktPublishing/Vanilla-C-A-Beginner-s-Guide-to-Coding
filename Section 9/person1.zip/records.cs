using System;

public class MyContacts
{
	static public void Main () 
    {
    	Person friend = new Person("Jim Wilson","34 Bay Road","1234567",175);
    	Person friend2 = new Person("Bill Todds","15 Mills Crescent","0987654",135);

    	Console.Clear();
    	friend.PrintDetails();
    	friend2.PrintDetails();
    }
}