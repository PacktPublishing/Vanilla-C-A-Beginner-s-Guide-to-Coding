using System;
 
public class ConcatenateStrings
{
    static public void Main () 
    {