using System;
 
public class MyCalculator
{
    static public void Main () 
    {

    }
}