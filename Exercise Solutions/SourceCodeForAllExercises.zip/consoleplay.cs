using System;

class ConsolePlay
{
	static void Main()
	{
		Console.BackgroundColor = ConsoleColor.Green;
		Console.ForegroundColor = ConsoleColor.Blue;
		Console.Clear();
		Console.WriteLine("Hello World");
	}


}