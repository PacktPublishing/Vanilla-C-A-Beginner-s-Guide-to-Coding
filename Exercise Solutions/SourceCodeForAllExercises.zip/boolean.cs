using System;
 
public class BooleanAlgebra
{
    static public void Main () 
    {
    	bool A = true;
    	bool B = true;

    	Console.WriteLine(A && B);
    }
}