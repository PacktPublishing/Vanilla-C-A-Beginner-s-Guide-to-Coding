using System;

public class CarCollection
{
	static public void Main () 
    {
    	Car newCar = new Car();
    }
}