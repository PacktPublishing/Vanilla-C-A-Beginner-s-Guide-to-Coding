using System;
 
public class Variables
{
    static public void Main ()
    {
        int number = 5/6;
        char myCharacter = 'A';
        float thisValue = 56.78f;
        Console.WriteLine ("{0} {1} {2}", number, myCharacter, thisValue);
    }
}