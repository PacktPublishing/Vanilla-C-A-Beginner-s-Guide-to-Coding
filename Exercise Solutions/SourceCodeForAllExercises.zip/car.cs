public class Car
{
   int wheels;
   int horsepower;
   string colour;
   bool convertible;
    
   public Car()
   {
      colour = "white";
      horsepower = 25;
      convertible = false;
      wheels = 4;
   }
}