using System;
 
public class SqrtTester
{
    static public void Main () 
    {
    	Console.Clear();
        Console.WriteLine("Hello");
    }
}

