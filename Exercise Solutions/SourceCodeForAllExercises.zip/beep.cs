using System;
 
public class Ceiling
{
    static public void Main () 
    {
    	Console.Beep();
    }
 }