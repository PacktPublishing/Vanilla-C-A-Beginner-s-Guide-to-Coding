using System;
 
public class Ceiling
{
    static public void Main () 
    {
    	double value = 10.9873;
    	Console.WriteLine("The ceiling of {0} is {1}",value,Math.Ceiling(value));
    }
 }