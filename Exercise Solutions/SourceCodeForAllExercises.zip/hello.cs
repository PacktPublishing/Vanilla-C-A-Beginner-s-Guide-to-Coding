using System;
 
public class HelloWorld
{
    static public void Main ()
    {
        Console.WriteLine ("Hello Penny");
    }
}